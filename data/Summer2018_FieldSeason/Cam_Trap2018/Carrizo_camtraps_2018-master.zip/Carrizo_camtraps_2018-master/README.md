# Carrizo_camtraps_2018
A set of code and data to support cam trap sampling in Carrizo National Momument
